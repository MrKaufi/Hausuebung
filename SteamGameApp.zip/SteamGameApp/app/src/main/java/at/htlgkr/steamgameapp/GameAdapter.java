package at.htlgkr.steamgameapp;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import at.htlgkr.steam.Game;

public class GameAdapter extends BaseAdapter {
    public GameAdapter(Context context, int listViewItemLayoutId, List<Game> games) {
        // Implementieren Sie diesen Konstruktor
    }

    @Override
    public int getCount() {
        // Implementiren Sie diese Methode
        return -1;
    }

    @Override
    public Object getItem(int position) {
        // Implementiren Sie diese Methode
        return null;
    }

    @Override
    public long getItemId(int position) {
        // Implementiren Sie diese Methode
        return -1;
    }

    @Override
    public View getView(int position, View givenView, ViewGroup parent) {
        //Implementieren Sie diese Methode;
        return null;
    }
}
