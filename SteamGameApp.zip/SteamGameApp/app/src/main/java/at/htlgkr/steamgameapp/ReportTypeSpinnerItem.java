package at.htlgkr.steamgameapp;

import at.htlgkr.steam.ReportType;

public class ReportTypeSpinnerItem {
    public ReportTypeSpinnerItem(ReportType type, String displayText) {
        // Implementieren Sie diesen Konstruktor
    }

    public ReportType getType(){
        // Implementieren Sie diese Methode.
        return null;
    }

    public String getDisplayText() {
        // Implementieren Sie diese Methode.
        return null;
    }

    @Override
    public String toString() {
        // Implementieren Sie diese Methode.
        return null;
    }
}