package at.htlgkr.steam;

public enum ReportType {
    NONE, SUM_GAME_PRICES, AVERAGE_GAME_PRICES, UNIQUE_GAMES, MOST_EXPENSIVE_GAMES
}
