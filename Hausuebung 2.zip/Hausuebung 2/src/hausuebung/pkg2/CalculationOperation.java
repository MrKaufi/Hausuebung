/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hausuebung.pkg2;

/**
 *
 * @author flori
 */
public interface CalculationOperation {
    Number calc(Number x, Number y);
}
